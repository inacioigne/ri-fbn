import {
  AsyncPipe,
  CommonModule,
} from '@angular/common';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import {
  ComponentFixture,
  fakeAsync,
  TestBed,
  tick,
  waitForAsync,
} from '@angular/core/testing';
import {
  ActivatedRoute,
  Router,
} from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { APP_CONFIG } from '@dspace/config/app-config.interface';
import { BrowseService } from '@dspace/core/browse/browse.service';
import { SortDirection } from '@dspace/core/cache/models/sort-options.model';
import { DSpaceObjectDataService } from '@dspace/core/data/dspace-object-data.service';
import { ItemDataService } from '@dspace/core/data/item-data.service';
import { PaginationService } from '@dspace/core/pagination/pagination.service';
import { BrowseEntry } from '@dspace/core/shared/browse-entry.model';
import { Community } from '@dspace/core/shared/community.model';
import { Item } from '@dspace/core/shared/item.model';
import { ActivatedRouteStub } from '@dspace/core/testing/active-router.stub';
import { PaginationServiceStub } from '@dspace/core/testing/pagination-service.stub';
import { RouterMock } from '@dspace/core/testing/router.mock';
import { createSuccessfulRemoteDataObject$ } from '@dspace/core/utilities/remote-data.utils';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { TranslateModule } from '@ngx-translate/core';
import { of } from 'rxjs';

import { environment } from '../../../environments/environment';
import { ThemedBrowseByComponent } from '../../shared/browse-by/themed-browse-by.component';
import { ThemedComcolPageBrowseByComponent } from '../../shared/comcol/comcol-page-browse-by/themed-comcol-page-browse-by.component';
import { ComcolPageContentComponent } from '../../shared/comcol/comcol-page-content/comcol-page-content.component';
import { ThemedComcolPageHandleComponent } from '../../shared/comcol/comcol-page-handle/themed-comcol-page-handle.component';
import { ComcolPageHeaderComponent } from '../../shared/comcol/comcol-page-header/comcol-page-header.component';
import { ComcolPageLogoComponent } from '../../shared/comcol/comcol-page-logo/comcol-page-logo.component';
import { DsoEditMenuComponent } from '../../shared/dso-page/dso-edit-menu/dso-edit-menu.component';
import { ThemedLoadingComponent } from '../../shared/loading/themed-loading.component';
import { EnumKeysPipe } from '../../shared/utils/enum-keys-pipe';
import { VarDirective } from '../../shared/utils/var.directive';
import { toRemoteData } from '../browse-by-metadata/browse-by-metadata.component.spec';
import { BrowseByTitleComponent } from './browse-by-title.component';

describe('BrowseByTitleComponent', () => {
  let comp: BrowseByTitleComponent;
  let fixture: ComponentFixture<BrowseByTitleComponent>;
  let itemDataService: ItemDataService;
  let route: ActivatedRoute;

  const mockCommunity = Object.assign(new Community(), {
    id: 'test-uuid',
    metadata: [
      {
        key: 'dc.title',
        value: 'test community',
      },
    ],
  });

  const mockItems = [
    Object.assign(new Item(), {
      id: 'fakeId',
      metadata: [
        {
          key: 'dc.title',
          value: 'Fake Title',
        },
      ],
    }),
  ];

  const mockBrowseService = {
    getBrowseItemsFor: () => toRemoteData(mockItems),
    getBrowseEntriesFor: () => toRemoteData([]),
    getConfiguredSortDirection: () => of(SortDirection.ASC),
  };

  const mockDsoService = {
    findById: () => createSuccessfulRemoteDataObject$(mockCommunity),
  };

  const activatedRouteStub = Object.assign(new ActivatedRouteStub({ id: 'title' }), {
    params: of({ id: 'title' }),
    queryParams: of({}),
    data: of({ metadata: 'title' }),
  });

  const paginationService = new PaginationServiceStub();

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [CommonModule, RouterTestingModule.withRoutes([]), TranslateModule.forRoot(), NgbModule, BrowseByTitleComponent, EnumKeysPipe, VarDirective, AsyncPipe],
      providers: [
        { provide: ActivatedRoute, useValue: activatedRouteStub },
        { provide: BrowseService, useValue: mockBrowseService },
        { provide: DSpaceObjectDataService, useValue: mockDsoService },
        { provide: PaginationService, useValue: paginationService },
        { provide: Router, useValue: new RouterMock() },
        { provide: APP_CONFIG, useValue: environment },
      ],
      schemas: [NO_ERRORS_SCHEMA],
    })
      .overrideComponent(BrowseByTitleComponent, {
        remove: { imports: [
          ComcolPageHeaderComponent,
          ComcolPageLogoComponent,
          ThemedComcolPageHandleComponent,
          ComcolPageContentComponent,
          DsoEditMenuComponent,
          ThemedComcolPageBrowseByComponent,
          ThemedLoadingComponent,
          ThemedBrowseByComponent,
        ] },
      })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BrowseByTitleComponent);
    comp = fixture.componentInstance;
    fixture.detectChanges();
    itemDataService = (comp as any).itemDataService;
    route = (comp as any).route;
  });

  it('should initialize the list of items', () => {
    comp.items$.subscribe((result) => {
      expect(result.payload.page).toEqual(mockItems);
    });
  });

  describe('when rendered in SSR', () => {
    beforeEach(() => {
      comp.platformId = 'server';
      spyOn((comp as any).browseService, 'getBrowseItemsFor');
      fixture.detectChanges();
    });

    it('should not call getBrowseItemsFor on init', (done) => {
      comp.ngOnInit();
      expect((comp as any).browseService.getBrowseItemsFor).not.toHaveBeenCalled();
      comp.loading$.subscribe((res) => {
        expect(res).toBeFalsy();
        done();
      });
    });
  });

  describe('when rendered in CSR', () => {
    beforeEach(() => {
      comp.platformId = 'browser';
      fixture.detectChanges();
      spyOn((comp as any).browseService, 'getBrowseItemsFor').and.returnValue(createSuccessfulRemoteDataObject$(new BrowseEntry()));
    });

    it('should call getBrowseItemsFor on init', fakeAsync(() => {
      comp.ngOnInit();
      tick(100);
      expect((comp as any).browseService.getBrowseItemsFor).toHaveBeenCalled();
    }));
  });
});
