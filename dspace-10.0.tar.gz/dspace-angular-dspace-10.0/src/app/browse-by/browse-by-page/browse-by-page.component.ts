import { AsyncPipe } from '@angular/common';
import {
  Component,
  OnInit,
} from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { BrowseByDataType } from '@dspace/core/browse/browse-by-data-type';
import { BrowseDefinition } from '@dspace/core/shared/browse-definition.model';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { BrowseBySwitcherComponent } from '../browse-by-switcher/browse-by-switcher.component';

@Component({
  selector: 'ds-browse-by-page',
  templateUrl: './browse-by-page.component.html',
  styleUrls: ['./browse-by-page.component.scss'],
  imports: [
    AsyncPipe,
    BrowseBySwitcherComponent,
  ],
})
export class BrowseByPageComponent implements OnInit {

  browseByType$: Observable<{type: BrowseByDataType }>;

  constructor(
    protected route: ActivatedRoute,
  ) {
  }

  /**
   * Fetch the correct browse-by component by using the relevant config from the route data
   */
  ngOnInit(): void {
    this.browseByType$ = this.route.data.pipe(
      map((data: { browseDefinition: BrowseDefinition }) => ({ type: data.browseDefinition.getRenderType() })),
    );
  }

}
