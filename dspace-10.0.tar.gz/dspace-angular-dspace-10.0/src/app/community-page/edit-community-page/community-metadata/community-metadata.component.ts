import { AsyncPipe } from '@angular/common';
import { Component } from '@angular/core';
import {
  ActivatedRoute,
  Router,
} from '@angular/router';
import { CommunityDataService } from '@dspace/core/data/community-data.service';
import { NotificationsService } from '@dspace/core/notification-system/notifications.service';
import { Community } from '@dspace/core/shared/community.model';
import { TranslateService } from '@ngx-translate/core';

import { ComcolMetadataComponent } from '../../../shared/comcol/comcol-forms/edit-comcol-page/comcol-metadata/comcol-metadata.component';
import { CommunityFormComponent } from '../../community-form/community-form.component';

/**
 * Component for editing a community's metadata
 */
@Component({
  selector: 'ds-community-metadata',
  templateUrl: './community-metadata.component.html',
  imports: [
    AsyncPipe,
    CommunityFormComponent,
  ],
})
export class CommunityMetadataComponent extends ComcolMetadataComponent<Community> {
  protected frontendURL = '/communities/';
  protected type = Community.type;

  public constructor(
    protected communityDataService: CommunityDataService,
    protected router: Router,
    protected route: ActivatedRoute,
    protected notificationsService: NotificationsService,
    protected translate: TranslateService,
  ) {
    super(communityDataService, router, route, notificationsService, translate);
  }
}
