import { AsyncPipe } from '@angular/common';
import {
  Component,
  OnInit,
} from '@angular/core';
import {
  ActivatedRoute,
  RouterLink,
} from '@angular/router';
import { DSONameService } from '@dspace/core/breadcrumbs/dso-name.service';
import { ItemTemplateDataService } from '@dspace/core/data/item-template-data.service';
import { RemoteData } from '@dspace/core/data/remote-data';
import { Collection } from '@dspace/core/shared/collection.model';
import { Item } from '@dspace/core/shared/item.model';
import { getFirstSucceededRemoteDataPayload } from '@dspace/core/shared/operators';
import { TranslateModule } from '@ngx-translate/core';
import { Observable } from 'rxjs';
import {
  first,
  map,
  switchMap,
} from 'rxjs/operators';

import { ThemedDsoEditMetadataComponent } from '../../dso-shared/dso-edit-metadata/themed-dso-edit-metadata.component';
import { AlertComponent } from '../../shared/alert/alert.component';
import { AlertType } from '../../shared/alert/alert-type';
import { ThemedLoadingComponent } from '../../shared/loading/themed-loading.component';
import { VarDirective } from '../../shared/utils/var.directive';
import { getCollectionEditRoute } from '../collection-page-routing-paths';

@Component({
  selector: 'ds-base-edit-item-template-page',
  templateUrl: './edit-item-template-page.component.html',
  imports: [
    AlertComponent,
    AsyncPipe,
    RouterLink,
    ThemedDsoEditMetadataComponent,
    ThemedLoadingComponent,
    TranslateModule,
    VarDirective,
  ],
})
/**
 * Component for editing the item template of a collection
 */
export class EditItemTemplatePageComponent implements OnInit {

  /**
   * The collection to edit the item template for
   */
  collectionRD$: Observable<RemoteData<Collection>>;

  /**
   * The template item
   */
  itemRD$: Observable<RemoteData<Item>>;

  /**
   * The AlertType enumeration
   * @type {AlertType}
   */
  AlertTypeEnum = AlertType;

  constructor(
    protected route: ActivatedRoute,
    public itemTemplateService: ItemTemplateDataService,
    public dsoNameService: DSONameService,
  ) {
  }

  ngOnInit(): void {
    this.collectionRD$ = this.route.parent.data.pipe(first(), map((data) => data.dso));
    this.itemRD$ = this.collectionRD$.pipe(
      getFirstSucceededRemoteDataPayload(),
      switchMap((collection) => this.itemTemplateService.findByCollectionID(collection.id)),
    );
  }

  /**
   * Get the URL to the collection's edit page
   * @param collection
   */
  getCollectionEditUrl(collection: Collection): string {
    if (collection) {
      return getCollectionEditRoute(collection.uuid);
    } else {
      return '';
    }
  }

}
